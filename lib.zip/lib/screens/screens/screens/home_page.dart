import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Converse'),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.pushNamed(context, '/cart');
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16.0),
            child: const Text(
              'Shop the Latest Styles',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(
            child: GridView.count(
              crossAxisCount: 2,
              children: List.generate(4, (index) {
                return Card(
                  child: Column(
                    children: [
                      Image.network(
                        'https://via.placeholder.com/150',
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Product ${index + 1}'),
                      ),
                      Text('\$${(index + 1) * 20}'),
                      ElevatedButton(
                        onPressed: () {
                          // Add to cart functionality here
                        },
                        child: const Text('Add to Cart'),
                      ),
                    ],
                  ),
                );
              }),
            ),
          ),
        ],
      ),
      bottomNavigationBar: const BottomAppBar(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Text('Fast, Free Shipping on orders over \$75'),
            Text('Worry-Free Returns within 30 days'),
          ],
        ),
      ),
    );
  }
}
